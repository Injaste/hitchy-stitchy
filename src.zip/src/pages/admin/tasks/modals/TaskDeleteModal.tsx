import { TriangleAlert } from "lucide-react"

import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import SubmitButton from "@/components/custom/form/SubmitButton"
import { useCloseOnSuccess } from "@/components/custom/form/useCloseOnSuccess"

import { useTaskModalStore } from "../hooks/useTaskModalStore"
import { useTaskMutations } from "../queries"
import { useAdminStore } from "@/pages/admin/store/useAdminStore"

const TaskDeleteModal = () => {
  const isDeleteOpen = useTaskModalStore((s) => s.isDeleteOpen)
  const selectedItem = useTaskModalStore((s) => s.selectedItem)
  const closeAll = useTaskModalStore((s) => s.closeAll)
  const { eventId } = useAdminStore()
  const { remove } = useTaskMutations()

  useCloseOnSuccess(remove.isSuccess, closeAll)

  if (!selectedItem) return null
  const task = selectedItem

  const handleConfirm = () => {
    remove.mutate({ event_id: eventId!, id: task.id, title: task.title });
  };

  return (
    <AlertDialog open={isDeleteOpen} onOpenChange={closeAll}>
      <AlertDialogContent>
        <AlertDialogHeader className="text-destructive">
          <AlertDialogTitle className="flex items-center gap-2">
            <TriangleAlert className="w-4 h-4 shrink-0" />
            Delete task
          </AlertDialogTitle>
          <AlertDialogDescription className="text-sm text-muted-foreground leading-relaxed">
            Are you sure you want to delete{" "}
            <span className="font-semibold text-foreground">"{task.title}"</span>?
            This action cannot be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>

        <AlertDialogFooter>
          <AlertDialogCancel
            variant="outline"
            size="sm"
            onClick={closeAll}
            disabled={remove.isPending}
            autoFocus
          >
            Cancel
          </AlertDialogCancel>
          <SubmitButton
            type="button"
            variant="destructive"
            size="sm"
            onClick={handleConfirm}
            isPending={remove.isPending}
            isSuccess={remove.isSuccess}
            isError={remove.isError}
          >
            Delete
          </SubmitButton>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}

export default TaskDeleteModal
