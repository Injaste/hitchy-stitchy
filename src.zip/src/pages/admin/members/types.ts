import { z } from "zod";
import type { Role } from "../roles/types";

export type MemberStatusLabel = "active" | "pending" | "frozen" | "rejected";

export interface Member {
  id: string;
  event_id: string;
  user_id: string | null;
  role_id: string;
  email: string;
  display_name: string;
  invited_by: string | null;
  frozen_at: string | null;
  invited_at: string;
  joined_at: string | null;
  rejected_at: string | null;
  created_at: string;
  updated_at: string;
  preferences: Record<string, unknown>;
  role: Role;
}

export const inviteMemberSchema = z.object({
  display_name: z
    .string()
    .min(1, "Name is required")
    .max(80, "Name is too long"),
  email: z.email("Enter a valid email"),
  role_id: z.string().min(1, "Select a role"),
});

export const editMemberSchema = z.object({
  display_name: z
    .string()
    .min(1, "Name is required")
    .max(80, "Name is too long"),
  role_id: z.string().min(1, "Select a role"),
});

export type InviteMemberValues = z.infer<typeof inviteMemberSchema>;
export type EditMemberValues = z.infer<typeof editMemberSchema>;

export interface InviteMemberPayload {
  event_id: string;
  display_name: string;
  email: string;
  role_id: string;
}

export interface UpdateMemberPayload {
  event_id: string;
  id: string;
  display_name: string;
  role_id: string;
}

export interface UpdateMyDisplayNamePayload {
  event_id: string;
  display_name: string;
}

export interface FreezeMemberPayload {
  event_id: string;
  id: string;
  freeze: boolean;
}

export interface DeleteMemberPayload {
  event_id: string;
  id: string;
  display_name: string;
}
