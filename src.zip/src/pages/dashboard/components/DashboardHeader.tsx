import { type FC } from "react";
import { Link } from "react-router-dom";
import { Plus, RefreshCw } from "lucide-react";
import { motion } from "framer-motion";

import { Button } from "@/components/ui/button";
import PortalToApp from "@/components/custom/portal-to-app";

import { itemFadeIn } from "@/lib/animations";
import type { EventsCount } from "../types";
import { cn } from "@/lib/utils";
import { useRefetch } from "@/pages/admin/hooks/useRefetch";

interface DashboardHeaderProps {
  eventsCount: EventsCount;
  isLoading: boolean;
  isFetching: boolean;
  refetch: () => void;
}

const DashboardHeader: FC<DashboardHeaderProps> = ({
  eventsCount,
  isLoading,
  isFetching,
  refetch,
}) => {
  const { handleRefresh, canRefresh } = useRefetch(refetch);

  const hasStats =
    eventsCount.pending > 0 ||
    eventsCount.active > 0 ||
    eventsCount.upcoming > 0;

  return (
    <div className="flex not-md:flex-col gap-4 justify-between items-start">
      <div>
        <p className="text-xs uppercase tracking-widest text-primary font-medium mb-1">
          Your events
        </p>
        <h1 className="font-bold text-3xl md:text-4xl text-foreground">
          Planning Dashboard
        </h1>
      </div>

      {!isLoading && (
        <motion.div
          variants={itemFadeIn}
          className="flex flex-row-reverse items-end gap-4"
        >
          <PortalToApp>
            <Link
              to="/create-event"
              className="fixed bottom-4 right-4 sm:hidden z-50"
            >
              <Button size="icon-xl" className="rounded-full shadow-lg">
                <Plus />
              </Button>
            </Link>
          </PortalToApp>

          <div className="flex gap-2 not-sm:hidden">
            <Button
              size="sm"
              variant="ghost"
              className="gap-1.5 text-muted-foreground"
              onClick={handleRefresh}
              disabled={!canRefresh}
            >
              <RefreshCw
                className={cn("size-3.5", isFetching && "animate-spin")}
              />
            </Button>
            <Link to="/create-event">
              <Button size="sm" variant="outline" className="gap-1.5">
                <Plus className="size-3.5" />
                New event
              </Button>
            </Link>
          </div>

          {hasStats && (
            <div className="flex items-center gap-3 text-right">
              {eventsCount.pending > 0 && (
                <>
                  <div>
                    <p className="text-xs uppercase tracking-widest text-muted-foreground font-medium">
                      Invited
                    </p>
                    <p className="text-lg font-bold text-foreground leading-none">
                      {eventsCount.pending}
                    </p>
                  </div>
                  <div className="w-px h-8 bg-border" />
                </>
              )}
              {eventsCount.active > 0 && (
                <>
                  <div>
                    <p className="text-xs uppercase tracking-widest text-muted-foreground font-medium">
                      Active
                    </p>
                    <p className="text-lg font-bold text-foreground leading-none">
                      {eventsCount.active}
                    </p>
                  </div>
                  <div className="w-px h-8 bg-border" />
                </>
              )}
              {eventsCount.upcoming > 0 && (
                <>
                  <div>
                    <p className="text-xs uppercase tracking-widest text-muted-foreground font-medium">
                      Upcoming
                    </p>
                    <p className="text-lg font-bold text-foreground leading-none">
                      {eventsCount.upcoming}
                    </p>
                  </div>
                  <div className="w-px h-8 bg-border" />
                </>
              )}
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
};

export default DashboardHeader;
