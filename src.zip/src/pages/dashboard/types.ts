export interface Event {
  id: string
  slug: string
  name: string
  date_start: string
  date_end: string
  is_pending: boolean
}

export interface EventsCount {
  active: number
  upcoming: number
  pending: number
}

export interface ClaimInvitePayload {
  event_id: string
  event_name: string
  action: "accept" | "reject"
}

export interface PendingInvite {
  id: string
  event_id: string
  display_name: string
  invited_at: string
  role_name: string | null
  event_name: string
  event_slug: string
  date_start: string
  date_end: string
}