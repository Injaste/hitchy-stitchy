import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { Slot } from "radix-ui";

import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "group/badge inline-flex h-5 w-fit shrink-0 items-center justify-center gap-1 overflow-hidden rounded-4xl border border-transparent px-2 py-0.5 text-xs font-medium whitespace-nowrap transition-all focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 aria-invalid:border-destructive aria-invalid:ring-destructive/20 &>svg]:pointer-events-none [&>svg]:size-3! transition-all",
  {
    variants: {
      variant: {
        default:
          "bg-primary/5 text-primary border-primary/20 [a]:hover:bg-primary/10",
        secondary:
          "bg-secondary/5 text-secondary border-secondary/20 [a]:hover:bg-secondary/10",
        success:
          "bg-success/5 text-success border-success/20 [a]:hover:bg-success/10",
        warning:
          "bg-warning/5 text-warning border-warning/20 [a]:hover:bg-warning/10",
        destructive:
          "bg-destructive/5 text-destructive border-destructive/20 [a]:hover:bg-destructive/10",
        outline:
          "bg-muted/40 text-muted-foreground border-muted [a]:hover:bg-muted/60",
        ghost:
          "bg-transparent text-muted-foreground border-transparent [a]:hover:bg-muted/40",
        link: "bg-transparent text-primary border-transparent underline-offset-4 hover:underline",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

function Badge({
  className,
  variant = "default",
  asChild = false,
  ...props
}: React.ComponentProps<"span"> &
  VariantProps<typeof badgeVariants> & { asChild?: boolean }) {
  const Comp = asChild ? Slot.Root : "span";

  return (
    <Comp
      data-slot="badge"
      data-variant={variant}
      className={cn(badgeVariants({ variant }), className)}
      {...props}
    />
  );
}

export { Badge, badgeVariants };
